import React, {useState} from 'react'

function UserForm({user,onSave,onCancel}) {

    const [formData, setFormData] = useState(user);

    const handleChange = (e)=>{
        const {name,value} = e.target ;
        setFormData({...formData,[name]:value});
    }

    const handleSubmit = (e)=>{
        e.preventDefault();
        onSave(formData);
    }

  return (
    <div className="card mt-4">
        <div className="card-header">{user.id ? "Edit User" : "Add User"}</div>
        <div className="card-body">
          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label>First Name</label>
              <input
                type="text"
                className="form-control"
                name="firstName"
                value={formData.firstName}
                onChange={handleChange}
                required
              />
            </div>
            <div className="form-group">
              <label>Last Name</label>
              <input
                type="text"
                className="form-control"
                name="lastName"
                value={formData.lastName}
                onChange={handleChange}
                required
              />
            </div>
            <div className="form-group">
              <label>Email</label>
              <input
                type="email"
                className="form-control"
                name="email"
                value={formData.email}
                onChange={handleChange}
                required
              />
            </div>
            <div className="mt-3">
              <button type="submit" className="btn btn-success mr-2">
                Save
              </button>
              <button type="button" className="btn btn-secondary" onClick={onCancel}>
                Cancel
              </button>
            </div>
          </form>
        </div>
    </div>
  )
}

export default UserForm
