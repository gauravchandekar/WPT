const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const PORT = 5000;

// Middleware
app.use(bodyParser.json());
app.use(cors());

// In-memory data store
let users = [];

// Routes
app.post('/new', (req, res) => {
  const { username, gender, dob } = req.body;
  if (!username || !gender || !dob) {
    return res.status(400).json({ error: 'All fields are required!' });
  }
  const newUser = { id: users.length + 1, username, gender, dob };
  users.push(newUser);
  res.status(201).json({ message: 'User added successfully!', user: newUser });
});

app.post('/list', (req, res) => {
  res.status(200).json({ users });
});

// Start server
app.listen(PORT, () => {
  console.log(`Backend running on http://localhost:${PORT}`);
});
