import React, { useState, useEffect } from 'react';
import axios from 'axios';
import AddUser from './AddUser';
import UserList from './UserList';

function App() {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const response = await axios.post('http://localhost:3000/list');
        setUsers(response.data.users);
      } catch (error) {
        console.error('Error fetching users:', error);
      }
    };

    fetchUsers();
  }, []);

  const handleUserAdded = (newUser) => {
    setUsers((prevUsers) => [...prevUsers, newUser]);
  };

  return (
    <div>
      <AddUser onUserAdded={handleUserAdded} />
      <UserList users={users} />
    </div>
  );
}

export default App;
